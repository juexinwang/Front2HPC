import MDAnalysis as mda

class Converter:
    def __init__(self,topfile,trajfile,outputfile):
        self.topfile=topfile
        self.trajfile=trajfile
        self.outputfile=outputfile
    def convert(self):
        trajfile=self.trajfile
        topfile=self.topfile
        outputfile=self.outputfile
        print(trajfile,topfile,outputfile)
        u=mda.Universe(topfile,trajfile)
        calpha_traj = u.select_atoms("name CA")
        with mda.Writer(outputfile, multiframe=True) as W:
            for ts in u.trajectory:
                print(ts)
                W.write(calpha_traj)

        ls = open(outputfile,'r').readlines()
        newls =[]
        for line in ls:
            if not line.startswith('CRY'):
                if line.startswith('ATOM'):
                    if line.split()[4]=='X':
                        line=line.replace(line.split()[4],'')
                        newls.append(line)
        with open(outputfile,"w") as f:
            for i in newls:
                f.writelines(i)

        
        

