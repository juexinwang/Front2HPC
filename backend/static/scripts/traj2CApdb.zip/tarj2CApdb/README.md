requirements:
    mdanalysis=2.2.0
how to install it:
    https://www.mdanalysis.org/pages/installation_quick_start/
example:
    python main.py --topfile ./examples/gromacs_traj/md.tpr --trajfile ./examples/gromacs_traj/md100f.xtc