import argparse
from modules.traj2CApdb import Converter
parser = argparse.ArgumentParser(
    'convert molecular dynamics simulations trajectory to CA trajectory file with pdb format')
parser.add_argument('--topfile', type=str,help='it is gro file in gromacs, promtop file in amber')
                
parser.add_argument("--trajfile", type=str, help="it is xtc file in gromacs, dcd file in amber")
                    
parser.add_argument('--outputfile', type=str, default='ca_traj.pdb',help='Number of residues of the PDB.')
args=parser.parse_args()
print(args)                
trajfile=args.trajfile
topfile=args.topfile
outputfile=args.outputfile
ct = Converter(topfile,trajfile,outputfile)
ct.convert()